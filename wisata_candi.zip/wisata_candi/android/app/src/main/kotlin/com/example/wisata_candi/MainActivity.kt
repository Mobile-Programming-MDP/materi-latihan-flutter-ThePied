package com.example.wisata_candi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
